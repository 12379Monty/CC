static inline double sqr(const double x) {return(x*x);}

static inline int SDDA_abs(const int x) {return((x<0)?(-x):x);}

static inline int SDDA_max(const int x, const int y) {return((x<y)?y:x);}


