
.First.lib <- function(lib,pkg) {
  library.dynam("SDDA",pkg,lib)
}
